//index.js
//获取应用实例
function f1(value) {
  return '函数基本定义';
}
Page({
  
  data: {
  },
  goLogin:function(){
    wx.navigateTo({
      url:'../login/login', //
 })
},
func:function(){
  wx.navigateTo({
    url:'../index/register', //
})
},
goRegister:function(){
  wx.navigateTo({
    url:'../register/register', //
})
},

  
})
// this.setData({ msg: "Hello World" })
