// pages/login/login.js

Page({

  /**
   * 页面的初始数据
   */
  data: {
    user: '', 
    password:''
  },
  /**
   * 获取输入账号
   */
  getName:function(event){
    var name=event.detail.value;
    this.setData({
      username:name
    })
  },
  /**
   * 获取输入密码
   */
  getPassword:function(event){
    var pwd=event.detail.value;
    this.setData({
      password:pwd
    })
  },
  onSubmit:function(e){
    var value = e.detail.value;
    var user=value.user;
    var pwd=value.pwd;
    this.setData({
      user:user,
      pwd:pwd
    });
    var that=this;
    that.checkLogin();
  },
  checkLogin:function(){
    var that = this;
    var user = that.data.user;
    var pwd = that.data.pwd;
    wx.login({
      success (res) {     
        if (res.code) {
          //发起网络请求
          wx.request({
            url: 'http://127.0.0.1/wx/public/index.php/index/user/read',
            data: {
              code: res.code,
              phone:user,
              pwd:pwd
            },
            method: 'POST',
            header: {
              "Content-Type": "application/x-www-form-urlencoded"
            },
            dataType:'json',
            success:function(d){
             
            }
          })
        } else {
          console.log('登录失败！' + res.errMsg)
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})