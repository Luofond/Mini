// pages/login/login.js

Page({

  /**
   * 页面的初始数据
   */
  data: {
    user: '', 
    password:''
  },
  /**
   * 获取输入账号
   */
  getName:function(event){
    var name=event.detail.value;
    this.setData({
      username:name
    })
  },
  /**
   * 获取输入密码
   */
  getPassword:function(event){
    var pwd=event.detail.value;
    this.setData({
      password:pwd
    })
  },
  onSubmit:function(e){
    var value = e.detail.value;
    var user=value.user;
    var pwd=value.pwd;
    this.setData({
      user:user,
      pwd:pwd
    });
    var that=this;
    that.checkLogin();
  },
  
  checkLogin:function(){
    var that = this;
    var phone = that.data.user;
    var pwd = that.data.pwd;
    if(phone==''){
      wx.showToast({
        title: '请输入手机号',
        icon: 'none',
        image:'../images/fail.png',
        duration: 2000
      })
      return false;
    }
    if(pwd==''){
      wx.showToast({
        title: '请输入密码',
        icon: 'none',
        image:'../images/fail.png',
        duration: 2000
      })
      return false;
    }
    var checkPhone=/^1(3|4|5|6|7|8|9)\d{9}$/;
    if(!(checkPhone.test(phone))){
      wx.showToast({
        title: '手机号格式错误！',
        icon: 'none',
        image:'../images/fail.png',
        duration: 2000
       
      })
      return false;
    }
    wx.request({
      url: 'http://127.0.0.1/wx/public/index.php/index/user/login',
      data: {
        phone:phone,
        pwd:pwd
      },
      method: 'POST',
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },

      success: function (res){
        if(res.data.status==0){
          wx.showToast({
            title:'登录失败',
            content:'没有注册或者账号密码不正确',
            duration: 2000
          })
        }else{
          wx.showToast({
            title:'登录成功',
            duration: 2000
          });
          // wx.setStorageSync('loginData', res.data);

          // wx.setStorageSync('key', res.data.status);
          wx.setStorageSync('userinfo',res.data.data);
         
          wx.switchTab({
            url:'../index/index', //
        })
        }
      }
    })
  },
  register:function(){
    wx.navigateTo({
      url:'../register/register', //
  })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    if(wx.getStorageSync('phone')){
      
      wx.switchTab({
        url:'../index/index', //
    })
    }
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})