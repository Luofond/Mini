
Page({
  data: {

  },
  onSubmit: function (event) {
    var value = event.detail.value;
    var phoneNumber = value.phoneNumber;
    var username = value.username;
    var pass = value.pass;
    var email = value.email;
    var checkPass = value.checkPass;
    this.setData({
      phoneNumber: phoneNumber,
      username: username,
      pass: pass,
      email: email,
      checkPass: checkPass,
    });
    var that=this;
    that.register();
  },
  register: function (event) {
    wx.clearStorageSync();
    var that = this;
    var phoneNumber = that.data.phoneNumber;
    var username = that.data.username;
    var email = that.data.email;
    var checkNum = that.data.checkNum;
    var pass = that.data.pass;
    var checkPass = that.data.checkPass;
    //判断信息输入完整
    if(phoneNumber==''||username==''||checkNum==''||pass==''||checkPass==''||email==''){
      wx.showToast({
        title: '信息不完整！',
        duration: 2000, 
      })
      return false;
    }else if(pass !== checkPass){
      wx.showToast({
        title: '两次密码不一致！',
        duration: 2000,
       
      })
      return false;
    }
    var checkPhone=/^1(3|4|5|6|7|8|9)\d{9}$/;
    if(!(checkPhone.test(phoneNumber))){
      wx.showToast({
        title: '手机号格式错误！',
        duration: 2000
      })
      return false;
    }
    var checkName= /^.{3,11}$/;
    if(!(checkName.test(username))){
      wx.showToast({
        title: '昵称为3-11位',
        duration: 2000,
      })
      return false;
    }
    var checkPass = /^.{6,15}$/; 
    if(!(checkPass.test(pass))){
      wx.showToast({
        title: '密码为3-15位',
        duration: 2000,
        
      })
      return false;
    }
    var checkEmail=/^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/;
    if(!checkEmail.test(email)){
      wx.showToast({
        title: '邮箱格式错误',
        duration: 2000,
        
      })
    }
    wx.showLoading({title: '注册中...'});
    wx.request({
      url: 'http://127.0.0.1/wx/public/index.php/index/user/add',
      method: 'POST',
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      data: {
        phone: phoneNumber,
        name: username,
        password: pass,
        email:email,
        checkNum: checkNum
      },
     
      success: function (res) {
        var message = (res.data.msg);
        if (message == "注册失败") {
          wx.showModal({
            title: '注册失败！',
            content: '注册失败！'
          });
          wx.hideLoading();
        }else if(message == "该手机号已经被注册"){
          wx.showModal({
            title: '注册失败！',
            content: '该手机号已经被注册'
          });
          wx.hideLoading();
          
        } else  {
          wx.hideLoading();
          wx.showModal({
            title: '注册成功',
            content: '请进行登录！'
          });
          setTimeout(function () {
            wx.redirectTo({
              url: "/pages/login/login"
            });
          }, 2000)
        }
      },
    })
  },
  login: function (event) {
    wx.redirectTo({
      url: "../login/login"
    });
  }
})
