<?php
namespace app\index\controller;
use think\Db;
class Index
{
    public function index()
   {
       $phone='2131';
       $pwd='123';
       $isOpenid=Db::name('user')
           ->field('id')
           ->where([
               "password"=>$pwd,
               "phone"	=>$phone
           ])
           ->find();
       dump($isOpenid);
   }
}
