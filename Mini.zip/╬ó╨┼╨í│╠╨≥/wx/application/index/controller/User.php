<?php
namespace app\index\controller;
use think\Controller;
use	app\index\model\User as	UserModel; 
use think\Db;
class User extends Controller{
    public function add(){
        $data=input('post.');
        // 先查询提交的注册信息是否存在
        $phone=$data['phone'];
        $isUser=Db::name('user')
                ->field('id')
                ->where("phone",$phone)
                ->find();
        if($isUser===null){
            $user=new UserModel;
             $user->name=$data['name'];
             $user->password=$data['password'];
             $user->email=$data['email'];
            $user->phone=$phone;
           
            if($user->save())	{
                $msg="注册成功";
            }else{
                $msg="注册失败";
            }
        }else{
            $msg='该手机号已经被注册';
           
        }
        
        $res=['msg'=>$msg];
        // dump($res);
        echo json_encode($res);
    }
   
    public function login(){
        $data=input('post.');
        // 先查询用户是否注册
        $phone=$data['phone'];
        $pwd=$data['pwd'];
        $isUser=Db::name('user')
            ->field('id,name,email,phone')
            ->where([
                "password"=>$pwd,
                "phone"	=>	$phone
            ])
            ->find();
        if (null===$isUser){
            $status = 0;
            $msg='没有注册或者账号密码不正确';
            $res=['status'=>$status, '$msg'=>$msg];
        }else{
            $status = 1;
            $msg = '登录成功';
            $res=['status'=>$status, '$msg'=>$msg, 'data'=>$isUser];
        }

        echo json_encode($res);
    }
//     public function read(){
//         $data=input('post.');
//         // 先查询用户是否注册
//         $phone=$data['phone'];
//         $pwd=$data['pwd'];
//         $isUser=Db::name('user')
//             ->field('id')
//             ->where([
//                 "password"=>$phone,
//                 "phone"	=>	$pwd
//             ])
//             ->find();
//         if (null===$isUser){
//             $msg='没有注册或者账号密码不正确';
//             return $msg;
//         }else{
//             $code=$data['code'];
//             $loginUrl ="https://api.weixin.qq.com/sns/jscode2session?appid=wx72a9bd697fe71f6b&secret=b718ed0a34626fe4a04d5ae1d4c379f8&js_code=".$code."&grant_type=authorization_code";
//             $res = file_get_contents($loginUrl);
//             $wxRes = json_decode($res,true);

//             $val = $wxRes['openid'] + "&" + $wxRes["session_key"];
//             $key = $wxRes["openid"] + time();
// //        openid写入数据库
//             $isOpenid=Db::name('user')
//                 ->field('id')
//                 ->where("openid",$wxRes['openid'])
//                 ->find();
//             if($isOpenid){
//                 $uid=$isOpenid['id'];
//             }else{
//                 $uid=$isUser['id'];
//                 Db::table('user')
//                     ->where("id",$uid)
//                     ->update(["openid"	=>	$wxRes['openid'] ]);
//             }
//             $key=md5($key);
//         }

//     }
    // public function test(){
    //     echo $this->_3rd_session(16);
    // }
    //  function _3rd_session($len)
    // {

    //     $fp = @fopen('/dev/urandom', 'rb');

    //     $result = '';

    //     if ($fp !== FALSE) {

    //         $result .= @fread($fp, $len);

    //         @fclose($fp);

    //     } else {

    //         trigger_error('Can not open /dev/urandom.');

    //     }

    //     // convert from binary to string

    //     $result = base64_encode($result);

    //     // remove none url chars

    //     $result = strtr($result, '+/', '-_');


    //     return substr($result, 0, $len);

    // }
    public function test(){
        $isUser=Db::name('user')
            ->field('id,name,email,phone')
            ->where([
                "password"=>"123",
                "phone"	=>	"123"
            ])
            ->find();
            var_dump($isUser);
    }

}